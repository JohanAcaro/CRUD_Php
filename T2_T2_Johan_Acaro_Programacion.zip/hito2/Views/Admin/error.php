<h2>La página solicitada no existe 404</h2>
<a href="?controller=admin&action=index">Volver a inicio</a>
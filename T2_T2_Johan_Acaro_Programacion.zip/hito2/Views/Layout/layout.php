<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="assets/css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

    <body>
    <header>
		<?php 
			require_once('cabecera.php');
		 ?>
		
	</header>
    <h4>CRUD con stored procedures</h4>

	<section>
	<?php require_once('routing.php'); 
        require_once('connection.php');
        $base=new DB();
		$conexion=$base->getConnect();

    ?>
	</section>

      <!--JavaScript at end of body for optimized loading-->
      <script type="text/javascript" src="assets/js/materialize.min.js"></script>
    </body>
</html>
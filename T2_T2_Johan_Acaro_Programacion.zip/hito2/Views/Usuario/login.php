<h5>Iniciar Sesión</h5>
<link type="text/css" rel="stylesheet" href="assets/css/estilo.css"/>

<div class="row">
  <form action="?controller=usuario&action=compare" method="post">
    <div class="row">
      <div class="input-field col s12">
        <input id="email" type="email" class="validate" name="correo">
        <label for="email">Correo</label>
      </div>
    </div>
    <div class="row">
      <div class="input-field col s12">
        <input id="password" type="password" class="validate" name="contraseña">
        <label for="password">Contraseña</label>
      </div>
    </div>
    
    <div class="row">      
      <div class="input-field col s12">
        <input type="submit" class="btn btn-primary" value="Iniciar Sesión">No tienes cuenta?
        <a class="btn btn-primary" href="?controller=usuario&action=register">Crear Cuenta</a>
      </div>
    </div>
  </form>
   
</div>

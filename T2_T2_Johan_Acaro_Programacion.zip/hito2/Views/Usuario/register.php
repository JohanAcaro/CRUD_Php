<h5>Crear Cuenta Usuario  </h5>
<link type="text/css" rel="stylesheet" href="assets/css/estilo.css"/>
<div id="error" class="alert alert-danger ocultar" role="alert">
    Las Contraseñas no coinciden, vuelve a intentar !
</div>
<div id="ok" class="alert alert-success ocultar" role="alert">
    Las Contraseñas coinciden ! (Procesando formulario ... )
</div>
<div class="row">
  <form action="?controller=usuario&action=save" method="post">
    <div class="row">
      <div class="input-field col s12">
        <input id="text" type="text" class="validate" name="nombre">
        <label for="text">Nombre</label>
      </div>
    </div>
    <div class="row">
      <div class="input-field col s12">
        <input id="password" type="password" class="validate" name="contraseña">
        <label for="password">Contraseña</label>
      </div>
    </div>
    <div class="row">
      <div class="input-field col s12">
        <input id="password2" type="password" class="validate" name="contraseña2">
        <label for="password2">Repetir Contraseña</label>
      </div>
    </div>
    <div class="row">
      <div class="input-field col s12">
        <input id="email" type="email" class="validate" name="correo">
        <label for="email">Correo</label>
      </div>
    </div>
    <div class="row">
      <div class="input-field col s12">
        <input id="foto" type="url" class="validate" name="foto"> 
        <label for="foto">Foto(url)</label>
      </div>
    </div>
    <div class="row">      
      <div class="input-field col s12">
        <input type="submit" class="btn btn-primary" value="Crear cuenta" onclick="validarClaves()">
      </div>
    </div>
  </form>
   
</div>
  <script src="assets/js/script.js"></script>
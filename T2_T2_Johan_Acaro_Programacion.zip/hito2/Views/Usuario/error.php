<h2>La página solicitada no existe 404</h2>
<a href="?controller=usuario&action=index">Volver a inicio</a>
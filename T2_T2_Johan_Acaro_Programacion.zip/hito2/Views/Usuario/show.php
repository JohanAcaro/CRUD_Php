<?php
//abrimos la sesión
session_start();
 
//Si la variable sesión está vacía
if (!isset($_SESSION['usuario'])) 
{
   /* nos envía a la siguiente dirección en el caso de no poseer autorización */
   header("location: index.php"); 
}
?>


<h6>Usuario</h6>
<div class="container">
	<h5>Cuenta Usuario</h5>
	<div class="table-responsive">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Id</th>
					<th>Nombre</th>
					<th>Contraseña</th>
					<th>Correo</th>
					<th>Foto</th>
				</tr>
				<tbody>
					<?php foreach ($listaUsuarios as $usuario) {?>

					
					<tr>
						<td><?php echo $usuario->getId(); ?></td>
						<td><?php echo $usuario->getNombre(); ?></td>
						<td><?php echo $usuario->getContraseña(); ?></td>
						<td><?php echo $usuario->getCorreo(); ?></td>
						<td><?php echo $usuario->getFoto(); ?></td>
						<td><a href="?controller=usuario&&action=updateshow&&idUsuario=<?php  echo $usuario->getId()?>">Actualizar</a></td>
						<td><a href="?controller=usuario&&action=delete&&id=<?php echo $usuario->getId() ?>">Eliminar</a></td>
					</tr>
					<?php } ?>
				</tbody>

			</thead>
		</table>

	</div>	

</div>
<a href="?controller=usuario&action=cerrar" class="btn btn-primary">Cerrar Sesión</a>
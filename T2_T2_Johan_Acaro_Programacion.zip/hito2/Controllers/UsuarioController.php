<?php 
/**
* 
*/
class UsuarioController
{
	
	function __construct()
	{
		
	}

	function index(){
		require_once('Views/Usuario/bienvenido.php');
	}
    function login(){
		require_once('Views/Usuario/login.php');
	}

	function register(){
		require_once('Views/Usuario/register.php');
	}

	function save(){

		$usuario= new Usuario(null, $_POST['nombre'],$_POST['contraseña'],$_POST['correo'],$_POST['foto']);

		Usuario::save($usuario);
		$this->show();
	}

	function show(){

		$listaUsuarios=Usuario::all();

		require_once('Views/Usuario/show.php');
	}

	function updateshow(){
		$id=$_GET['idUsuario'];
		$usuario=Usuario::searchById($id);
		require_once('Views/Usuario/updateshow.php');
	}

	function update(){
		$usuario = new Usuario($_POST['id'],$_POST['nombre'],$_POST['contraseña'],$_POST['correo'],$_POST['foto']);
		Usuario::update($usuario);
		$this->show();
	}
	function delete(){
		$id=$_GET['id'];
		Usuario::delete($id);
		$this->show();
	}

	function search(){
	 	if (!empty($_POST['id'])) {
	 		$id=$_POST['id'];
	 		$usuario=Usuario::searchById($id);
	 		$listaUsuarios[]=$usuario;
	 		//var_dump($id);
	 		//die();
	 		require_once('Views/Usuario/show.php');
	 	} else {
	 		$listaUsuarios=Usuario::all();

			require_once('Views/Usuario/show.php');
	 	}
		
		
	}
	function contacto(){
		require_once('Views/Usuario/contacto.php');
	}


	function error(){
		require_once('Views/Usuario/error.php');
	}
    function compare(){
		
		$correo = $_POST['correo'];
		$contraseña = $_POST['contraseña'];

		$base=new Db();
		$conexion=$base->getConnect();
		$admin = $conexion->prepare('select * from admins where correo = ? and contraseña = ?;');
		$usuario = $conexion->prepare('select * from usuarios where correo = ? and contraseña = ?;');

		$admin->execute([$correo, $contraseña]);
		$usuario->execute([$correo, $contraseña]);
		$datos_ad = $admin->fetch(PDO::FETCH_OBJ);
		$datos_usu = $usuario->fetch(PDO::FETCH_OBJ);
		//print_r($datos);

		if($admin->rowCount() == 1){
			session_start();
			$_SESSION['admin'] = $datos_ad;
			
			header('Location: ?controller=admin&action=show');
			exit();
		}
		elseif($usuario->rowCount() == 1){
			session_start();
			$_SESSION['usuario'] = $datos_usu;
			
			header('Location: ?controller=usuario&action=show');
			exit();

		}
		else{
			printf("<script type='text/javascript'>alert('Credenciales incorrectas'); </script>");
			//header('Location: ?controller=usuario&action=login');
            printf("<script> window.location='?controller=usuario&action=login';</script>");
		}
		
	}
	function cerrar(){
		session_start();
 
		/* comprobamos que un usuario registrado es el que accede al archivo, 
		sino no tendría sentido que pasara por este archivo */
		if (!isset($_SESSION['usuario'])) 
		{
			header("location: index.php"); 
		}
		
		/* usamos la función session_unset() para liberar la variable 
		de sesión que se encuentra registrada */
		session_unset();
		
		// Destruye la información de la sesión
		session_destroy();
		
		//volvemos a la página principal
		header("location: index.php");
	}

}
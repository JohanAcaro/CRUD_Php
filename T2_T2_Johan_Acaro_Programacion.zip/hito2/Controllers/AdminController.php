<?php 
/**
* 
*/
class AdminController
{
	
	function __construct()
	{
		
	}

	function index(){
		require_once('Views/Admin/bienvenido.php');
	}

	function register(){
		require_once('Views/Admin/register.php');
	}

	function save(){

		$admin= new Admin(null, $_POST['nombre'],$_POST['contraseña'],$_POST['correo'],$_POST['foto']);

		Admin::save($admin);
		$this->show();
	}

	function show(){

		$listaUsuarios=Admin::all();

		require_once('Views/Admin/show.php');
	}

	function updateshow(){
		$id=$_GET['idUsuario'];
		$usuario=Admin::searchById($id);
		require_once('Views/Admin/updateshow.php');
	}

	function update(){
		$usuario = new Admin($_POST['id'],$_POST['nombre'],$_POST['contraseña'],$_POST['correo'],$_POST['foto']);
		Admin::update($usuario);
		$this->show();
	}
	function delete(){
		$id=$_GET['id'];
		Admin::delete($id);
		$this->show();
	}

	function search(){
	 	if (!empty($_POST['id'])) {
	 		$id=$_POST['id'];
	 		$usuario=Admin::searchById($id);
	 		$listaUsuarios[]=$usuario;
	 		//var_dump($id);
	 		//die();
	 		require_once('Views/Admin/show.php');
	 	} else {
	 		$listaUsuarios=Admin::all();

			require_once('Views/Admin/show.php');
	 	}
		
		
	}

	function error(){
		require_once('Views/Admin/error.php');
	}
    

	function cerrar(){
		session_start();
 
		/* comprobamos que un usuario registrado es el que accede al archivo, 
		sino no tendría sentido que pasara por este archivo */
		if (!isset($_SESSION['admin'])) 
		{
			header("location: index.php"); 
		}
		
		/* usamos la función session_unset() para liberar la variable 
		de sesión que se encuentra registrada */
		session_unset();
		
		// Destruye la información de la sesión
		session_destroy();
		
		//volvemos a la página principal
		header("location: index.php");
	}

}
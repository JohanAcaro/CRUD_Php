<nav>
    <div class="nav-wrapper">
      <a href="#" class="brand-logo right">Logo</a>
      <ul id="nav-mobile" class="left hide-on-med-and-down">
        <li><a href="?controller=usuario&action=index">Home</a></li>
        <li><a href="?controller=usuario&action=login">Iniciar Sesión</a></li>
        <li><a href="?controller=usuario&action=register">Registrar</a></li>
        <li><a href="?controller=usuario&action=contacto">Contacto</a></li>
      </ul>
    </div>
  </nav>
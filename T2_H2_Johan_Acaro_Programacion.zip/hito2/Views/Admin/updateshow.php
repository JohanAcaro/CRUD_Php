<div class="container">
	<h5>Actualizar Usuario</h5>
	<form action="?controller=admin&&action=update" method="POST">
		<input type="hidden" name="id" value="<?php echo $usuario->getId() ?>" >
		<div class="form-group">
			<label for="text">Nombre</label>
			<input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo $usuario->getNombre() ?>">
		</div>
		<div class="form-group">
			<label for="text">Contraseña</label>
			<input type="text" name="contraseña" id="contraseña" class="form-control" value="<?php echo $usuario->getContraseña(); ?>">
		</div>
		<div class="form-group">
			<label for="text">Correo</label>
			<input type="text" name="correo" id="correo" class="form-control" value="<?php echo $usuario->getCorreo(); ?>">
		</div>
		<div class="form-group">
			<label for="text">Foto</label>
			<input type="text" name="foto" id="foto" class="form-control" value="<?php echo $usuario->getFoto(); ?>">
		</div>
		
		<button type="submit" class="btn btn-primary">Actualizar</button>

	</form>
</div>
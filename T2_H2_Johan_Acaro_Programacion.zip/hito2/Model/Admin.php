<?php
//model
class Admin{

    private $id;
    private $nombre;
    private $contraseña;
    private $correo;
    private $foto;

    function __construct($id,$nombre,$contraseña,$correo,$foto){
        $this->setId($id);
		$this->setNombre($nombre);
		$this->setContraseña($contraseña);
		$this->setCorreo($correo);
		$this->setFoto($foto);
    }

    
    public function getId(){
		return $this->id;
	}
	public function setId($id){
		$this->id = $id;
	}


    public function getNombre(){
		return $this->nombre;
	}
	public function setNombre($nombre){
		$this->nombre = $nombre;
	}


	public function getContraseña(){
		return $this->contraseña;
	}
	public function setContraseña($contraseña){
		$this->contraseña = $contraseña;
	}


	public function getCorreo(){
		return $this->correo;
	}
	public function setCorreo($correo){
		$this->correo = $correo;
	}


    public function getFoto(){
		return $this->foto;
	}
	public function setFoto($foto){
		$this->foto = $foto;
	}
    //finaliza model

    //ApiService : métodos de CRUD
    public static function save($admin){
		$db=Db::getConnect();
		//var_dump($alumno);
		//die();
		

		$insert=$db->prepare("INSERT INTO admins VALUES (NULL,:nombre,:contrasena,:correo,:foto)");
		$insert->bindValue('nombre',$admin->getNombre());
		$insert->bindValue('contrasena',$admin->getContraseña());
		$insert->bindValue('correo',$admin->getCorreo());
		$insert->bindValue('foto',$admin->getFoto());
		$insert->execute();
	}

	public static function all(){
	 	$db=Db::getConnect();
	 	$listaUsuarios=[];

	 	$select=$db->query('SELECT * FROM usuarios order by id');

	 	foreach($select->fetchAll() as $usuario){
	 		$listaUsuarios[]=new Admin($usuario['id'],$usuario['nombre'],$usuario['contraseña'],$usuario['correo'],$usuario['foto']);
	 	}
	 	return $listaUsuarios;
	}

	public static function searchById($id){
	 	$db=Db::getConnect();
	 	$select=$db->prepare('SELECT * FROM usuarios WHERE id=:id');
	 	$select->bindValue('id',$id);
	 	$select->execute();

		$usuarioDb=$select->fetch();


	 	$usuario = new Admin ($usuarioDb['id'],$usuarioDb['nombre'], $usuarioDb['contraseña'], $usuarioDb['correo'],$usuarioDb['foto']);
	 	//var_dump($alumno);
	 	//die();
	 	return $usuario;

	}

	public static function update($usuario){
		$db=Db::getConnect();
		$update=$db->prepare('UPDATE usuarios SET nombre=:nombre, contrasena=:contrasena, correo=:correo, foto=:foto WHERE id=:id');
		$update->bindValue('nombre', $usuario->getNombre());
		$update->bindValue('contrasena',$usuario->getContraseña());
		$update->bindValue('correo',$usuario->getCorreo());
		$update->bindValue('foto', $usuario->getFoto());
		$update->bindValue('id',$usuario->getId());
		
		$update->execute();
	}

	public static function delete($id){
		$db=Db::getConnect();
		$delete=$db->prepare('DELETE  FROM usuarios WHERE id=:id');
		$delete->bindValue('id',$id);
		$delete->execute();		
	}
}//cierra Alumno
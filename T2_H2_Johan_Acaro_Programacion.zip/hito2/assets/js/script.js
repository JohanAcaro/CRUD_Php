 
function validarClaves() {
    // Ontenemos los valores de los campos de contraseñas 
    pass1 = document.getElementById('password');
    pass2 = document.getElementById('password2');
 
    // Verificamos si las constraseñas no coinciden 
    if (pass1.value != pass2.value) {
 
        setTimeout(function(){ 
            document.getElementById("error").classList.add("mostrar");
        }, 1000); 
        event.preventDefault();
    } 
    
    else {
        document.getElementById("error").classList.remove("mostrar");

    }
}


        
    
